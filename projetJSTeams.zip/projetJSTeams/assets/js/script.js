let userChoice

let userVictory = false
let iaVictory = false

let iaVictoryCount 
let userVictoryCount

var elfe = document.getElementById('elfe')
elfe.addEventListener('click', getUserChoice)
var orc = document.getElementById('orc')
orc.addEventListener('click', getUserChoice)
var hobbit = document.getElementById('hobbit')
hobbit.addEventListener('click', getUserChoice)
var humain = document.getElementById('humain')
humain.addEventListener('click', getUserChoice)
var nain = document.getElementById('nain')
nain.addEventListener('click', getUserChoice)

function getUserChoice(){
    userChoice = parseInt(this.getAttribute('data-variable'))
    return userChoice
}


function getIaChoice(max) {
    return  (Math.random() * max)
}

function startGame(userChoice) {
    let iaChoice = getIaChoice(5)
    if (userChoice == 0 && iaChoice == 1) {
        userVictory = true
    } else if (userChoice == 1 && iaChoice == 0) {
        iaVictory = True
    } else if (userChoice == 1 && iaChoice == 2) {
        userVictory = true
    } else if (userChoice == 2 && iaChoice == 1) {
        iaVictory = True
    } else if (userChoice == 2 && iaChoice == 3) {
        userVictory = true
    } else if (userChoice == 3 && iaChoice == 2) {
        iaVictory = True
    } else if (userChoice == 3 && iaChoice == 4) {
        userVictory = true
    } else if (userChoice == 4 && iaChoice == 3) {
        iaVictory = True
    } else if (userChoice == 4 && iaChoice == 0) {
        userVictory = true
    } else if (userChoice == 0 && iaChoice == 4) {
        iaVictory = True
    } else if (userChoice == 0 && iaChoice == 3) {
        userVictory = true
    } else if (userChoice == 3 && iaChoice == 0) {
        iaVictory = True
    } else if (userChoice == 3 && iaChoice == 1) {
        userVictory = true
    } else if (userChoice == 1 && iaChoice == 3) {
        iaVictory = True
    } else if (userChoice == 1 && iaChoice == 4) {
        userVictory = true
    } else if (userChoice == 4 && iaChoice == 1) {
        iaVictory = True
    } else if (userChoice == 4 && iaChoice == 2) {
        userVictory = true
    } else if (userChoice == 2 && iaChoice == 4) {
        iaVictory = True
    } else if (userChoice == 2 && iaChoice == 0) {
        userVictory = true
    }else if (userChoice == 0 && iaChoice == 2) {
        iaVictory = True
    } else if (userChoice == iaChoice) {
        alert("Égalité ! Choisissez à nouveau !")
    }

    if (iaVictory == true ){
        let userHealth = document.getElementById("playerHealthBar").children
        let index = userHealth.length - 1
        while (index >= 0 && userHealth[index].classList.includes("fa-regular")){
            index --
        }
        if (iaHealth[index].classList.includes("fa-solid") ){
            iaHealth[index].classList.remove("fa-heart")
            iaHealth[index].classList.remove("fa-solid")
            iaHealth[index].classList.add("fa-regular")
            iaHealth[index].classList.add("fa-heart-half-stroke")
        } else if (iaHealth[index].classList.includes("fa-heart-half-stroke") ){
            iaHealth[index].classList.remove("fa-heart-half-stroke")
            iaHealth[index].classList.add("fa-heart")
        } else {
            alert (" Vous avez perdu !")
            iaVictoryCount += 1 
            while 
            
        }
    }

    if (userVictory == true ){
        let iaHealth = document.getElementById("iaHealthBar").children
        let index = iaHealth.length - 1
        while (index >= 0 && iaHealth[index].classList.includes("fa-regular")){
            index --
        }
        if (iaHealth[index].classList.includes("fa-solid") ){
            iaHealth[index].classList.remove("fa-heart")
            iaHealth[index].classList.remove("fa-solid")
            iaHealth[index].classList.add("fa-regular")
            iaHealth[index].classList.add("fa-heart-half-stroke")
        } else if (iaHealth[index].classList.includes("fa-heart-half-stroke") ){
            iaHealth[index].classList.remove("fa-heart-half-stroke")
            iaHealth[index].classList.add("fa-heart")
        } else {
            alert (" Vous avez gagné !")
            userVictoryCount += 1
            reload()
        }
    }
}


function getStarsFromVote(score) { /*fonction qui permet de mettre la moyenne des notes sur 10 en étoiles*/
let iaScore = 3
let userScore = 3
    score = parseInt(score+0.5)/2;
    container = document.createElement("div");
    let n_fill = parseInt(score);
    let n_half = parseInt(score-n_fill+0.5);
    for (let i = 0; i < 3; i++) {
        let star = document.createElement("i");
        if (i < n_fill) {
            star.classList.add("fa-solid", "fa-star"); 
        }else if (i < n_fill+n_half) {
            star.classList.add("fa-solid", "fa-star-half-stroke");
        }else {star.classList.add("fa-regular", "fa-star");}
        container.append(star);
    }
    return container.innerHTML;
}