let userChoice

let iaVictoryCount 
let userVictoryCount

    

let userHealth = 3
let iaHealth = 3

var elfe = document.getElementById('elfe')
elfe.addEventListener('click', () => {startGame(0)})
var orc = document.getElementById('orc')
orc.addEventListener('click', () => {startGame(1)})
var hobbit = document.getElementById('hobbit')
hobbit.addEventListener('click', () => {startGame(2)})
var humain = document.getElementById('humain')
humain.addEventListener('click', () => {startGame(3)})
var nain = document.getElementById('nain')
nain.addEventListener('click', () => {startGame(4)})

function getIaChoice(max) {
    return  parseInt(Math.random() * max)
}

function startGame(userChoice) {
    let userVictory = false
    let iaVictory = false
    console.log('Choix user '+userChoice)
    let iaChoice = getIaChoice(5)
    console.log('Choix IA '+iaChoice)
    if (userChoice == 0 && iaChoice == 1) {
        userVictory = true
    } else if (userChoice == 1 && iaChoice == 0) {
        iaVictory = true
    } else if (userChoice == 1 && iaChoice == 2) {
        userVictory = true
    } else if (userChoice == 2 && iaChoice == 1) {
        iaVictory = true
    } else if (userChoice == 2 && iaChoice == 3) {
        userVictory = true
    } else if (userChoice == 3 && iaChoice == 2) {
        iaVictory = true
    } else if (userChoice == 3 && iaChoice == 4) {
        userVictory = true
    } else if (userChoice == 4 && iaChoice == 3) {
        iaVictory = true
    } else if (userChoice == 4 && iaChoice == 0) {
        userVictory = true
    } else if (userChoice == 0 && iaChoice == 4) {
        iaVictory = true
    } else if (userChoice == 0 && iaChoice == 3) {
        userVictory = true
    } else if (userChoice == 3 && iaChoice == 0) {
        iaVictory = true
    } else if (userChoice == 3 && iaChoice == 1) {
        userVictory = true
    } else if (userChoice == 1 && iaChoice == 3) {
        iaVictory = true
    } else if (userChoice == 1 && iaChoice == 4) {
        userVictory = true
    } else if (userChoice == 4 && iaChoice == 1) {
        iaVictory = true
    } else if (userChoice == 4 && iaChoice == 2) {
        userVictory = true
    } else if (userChoice == 2 && iaChoice == 4) {
        iaVictory = true
    } else if (userChoice == 2 && iaChoice == 0) {
        userVictory = true
    }else if (userChoice == 0 && iaChoice == 2) {
        iaVictory = true
    }

    if (userChoice == iaChoice) {
        alert("Égalité ! Choisissez à nouveau !")
    }

    if (iaVictory == true ){
        alert("L'IA gagne !")
        userHealth = parseInt(userHealth - 1)
        getUserHealth(userHealth)
    }

    function getUserHealth(userHealth){
        let container = document.getElementById("playerHealthBar")
        container.setAttribute('id','playerHealthBar')
        if  (userHealth == 3){
            container.innerHTML = `
            <i class="fa-solid fa-heart fa-3x"></i>  
            <i class="fa-solid fa-heart fa-3x"></i>
            <i class="fa-solid fa-heart fa-3x"></i>
            `
        }else if (userHealth == 2){
            container.innerHTML = `
            <i class="fa-solid fa-heart fa-3x"></i>
            <i class="fa-solid fa-heart fa-3x"></i>
            <i class="fa-regular fa-heart fa-3x"></i>  
            `
        }else if (userHealth == 1){
            container.innerHTML = `
            <i class="fa-solid fa-heart fa-3x"></i>
            <i class="fa-regular fa-heart fa-3x"></i>
            <i class="fa-regular fa-heart fa-3x"></i> 
            `
        }else if (userHealth == 0){
            container.innerHTML = `
            <i class="fa-regular fa-heart fa-3x"></i>
            <i class="fa-regular fa-heart fa-3x"></i>
            <i class="fa-regular fa-heart fa-3x"></i>
            `
        }
        console.log(container)
        return container
    }

    if (userVictory == true ){
        alert("Vous gagnez !")
        iaHealth = parseInt(iaHealth - 1)
        getIaHealth(iaHealth)
    }

    function getIaHealth(iaHealth){
        let container = document.getElementById("iaHealthBar")
        container.setAttribute('id','iaHealthBar')
        if (iaHealth == 3){
            container.innerHTML = `
            <i class="fa-solid fa-heart fa-3x"></i>  
            <i class="fa-solid fa-heart fa-3x"></i>  
            <i class="fa-solid fa-heart fa-3x"></i>  
            `
        }else if (iaHealth == 2){
            container.innerHTML = `
            <i class="fa-solid fa-heart fa-3x"></i>
            <i class="fa-solid fa-heart fa-3x"></i>  
            <i class="fa-regular fa-heart fa-3x"></i>  
            `
        }else if (iaHealth == 1){
            container.innerHTML = `
            <i class="fa-solid fa-heart fa-3x"></i>  
            <i class="fa-regular fa-heart fa-3x"></i>
            <i class="fa-regular fa-heart fa-3x"></i> 
            `
        }else if (iaHealth == 0){
            container.innerHTML = `
            <i class="fa-regular fa-heart fa-3x"></i>
            <i class="fa-regular fa-heart fa-3x"></i>
            <i class="fa-regular fa-heart fa-3x"></i>
            `
        }
        console.log(container)
        return container
    }
    
}


function getStarsFromVote(score) { /*fonction qui permet de mettre la moyenne des notes sur 10 en étoiles*/
let iaScore = 3
let userScore = 3
    score = parseInt(score+0.5)/2;
    container = document.createElement("div");
    let n_fill = parseInt(score);
    let n_half = parseInt(score-n_fill+0.5);
    for (let i = 0; i < 3; i++) {
        let star = document.createElement("i");
        if (i < n_fill) {
            star.classList.add("fa-solid", "fa-star"); 
        }else if (i < n_fill+n_half) {
            star.classList.add("fa-solid", "fa-star-half-stroke");
        }else {star.classList.add("fa-regular", "fa-star");}
        container.append(star);
    }
    return container.innerHTML;
}