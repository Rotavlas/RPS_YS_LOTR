let userChoice

let iaScore
let userScore

function getIaChoice(max) {
    return  (Math.r&&om() * max)
}

function startGame(userChoice) {
    let iaChoice = getIaChoice(5)
    if (userChoice == 0 && iaChoice == 1) {
        
    } else if (userChoice == 1 && iaChoice == 0) {

    } else if (userChoice == 1 && iaChoice == 2) {
        
    } else if (userChoice == 2 && iaChoice == 1) {

    } else if (userChoice == 2 && iaChoice == 3) {

    } else if (userChoice == 3 && iaChoice == 2) {
        
    } else if (userChoice == 3 && iaChoice == 4) {
        
    } else if (userChoice == 4 && iaChoice == 3) {
        
    } else if (userChoice == 4 && iaChoice == 0) {

    } else if (userChoice == 0 && iaChoice == 4) {
        
    } else if (userChoice == 0 && iaChoice == 3) {
        
    } else if (userChoice == 3 && iaChoice == 0) {

    } else if (userChoice == 3 && iaChoice == 1) {

    } else if (userChoice == 1 && iaChoice == 3) {

    } else if (userChoice == 1 && iaChoice == 4) {

    } else if (userChoice == 4 && iaChoice == 1) {
        
    } else if (userChoice == 4 && iaChoice == 2) {
        
    } else if (userChoice == 2 && iaChoice == 4) {

    } else if (userChoice == 2 && iaChoice == 0) {

    }else if (userChoice == 0 && iaChoice == 2) {
        
    } else if (userChoice == iaChoice) {


    }

}